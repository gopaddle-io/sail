package main

import (
	"fmt"
	directory "gopaddle/nodechecker/directory"
	nodevalidator "gopaddle/nodechecker/nodevalidator"
	nodevalidatorctrl "gopaddle/nodechecker/nodevalidator/ctrl"
	util "gopaddle/nodechecker/util"
	db "gopaddle/nodechecker/util/db"
	json "gopaddle/nodechecker/util/json"
	clog "gopaddle/nodechecker/util/log"
	"log"
	"net/http"
	"os"
	"runtime"

	"github.com/codegangsta/negroni"
	"github.com/gorilla/mux"
)

const (
	config = "./config/profiles-%s.json"
)

var platform string
var validity string

func main() {
	port := ":8020"

	runtime.GOMAXPROCS(runtime.NumCPU())
	args := os.Args[1:]
	var env string
	if len(args) < 1 {
		log.Println("Sever Environment is not given,\n\t $ ./server <profile>")
		os.Exit(0)
	}

	env = args[0]
	log.Println("Selected Environment : ", env)

	//Loading Config data to context
	res := directory.LoadConfig(env)
	if res == false {
		log.Println("Config not loaded")
		os.Exit(0)
	}
	clog.Init()
	//To load configDirectory
	// go loadDirectoryConfig(env)
	db.Instance().Info()
	route := mux.NewRouter()
	route.Headers("Content-Type", "application/json", "X-Requested-With", "XMLHttpRequest")
	fmt.Println("install mode = ", platform)
	if platform == "" {
		fmt.Println("install mode not set")
		os.Exit(0)
	}
	if platform == "onprem" {
		nodevalidatorctrl.SetNodeEnv()
		nodevalidatorctrl.SetValidity(validity)
	}

	/* Server Specific API */
	route.HandleFunc("/api/status", GetStatus).Methods("GET")
	route.HandleFunc("/api/version", GetVersion).Methods("GET")

	/* Notification API call's */
	// route.HandleFunc("/api/{accountID}/v1/nodevalidator", notification.Register).Methods("POST")
	// route.HandleFunc("/api/v1/nodechecker", Read).Methods("GET")
	route.Handle("/api/v1/nodechecker",
		negroni.New(
			negroni.HandlerFunc(Read),
			negroni.HandlerFunc(nodevalidator.Read),
		)).Methods("GET")
	// route.HandleFunc("/api/{accountID}/v1/nodechecker/{notificationID}", notification.Update).Methods("PUT")
	// route.HandleFunc("/api/{accountID}/v1/nodechecker", notification.List).Methods("GET")
	// route.HandleFunc("/api/{accountID}/v1/nodechecker/{notificationID}", notification.Delete).Methods("DELETE")

	log.Printf("Server listening at %s", port)
	e := http.ListenAndServe(port, route)
	if e != nil {
		log.Fatalf("Error While establishing connection: %v", e)
	}

}
func Read(rw http.ResponseWriter, req *http.Request, next http.HandlerFunc) {
	if platform == "saas" {
		rw.WriteHeader(200)
		rw.Write([]byte("success"))
	}
	if platform == "onprem" {
		next(rw, req)
	}
	if platform != "onprem" && platform != "saas" {
		fmt.Println("platform not set")
		rw.WriteHeader(500)
		rw.Write([]byte("platform not set"))
	}
}

// GetStatus to get status of service
func GetStatus(rw http.ResponseWriter, req *http.Request) {
	jobj := json.New()
	jobj.Put("status", "Running")
	rw.WriteHeader(200)
	rw.Write([]byte(jobj.ToString()))
}

// GetVersion to get version of service
func GetVersion(rw http.ResponseWriter, req *http.Request) {
	config, err := util.LoadConfig(config, "")
	jobj := json.New()
	if err != nil {
		jobj.Put("reason", err.Error())
		rw.WriteHeader(404)
		rw.Write([]byte(jobj.ToString()))
		return
	}
	jobj.Put("version", config.GetString("version"))
	rw.WriteHeader(200)
	rw.Write([]byte(jobj.ToString()))
}

//It will periodically load configDirectory
// func loadDirectoryConfig(env string) {
// 	for {
// 		directory.LoadDirectory(env)
// 		//Wait for 30 secs between each call
// 		timer := time.NewTimer(time.Second * 300)
// 		<-timer.C
// 	}
// }
