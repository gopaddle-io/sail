package validation

// // GetError Get notification validation error
// func (nfcVde *nfcValidation) GetError() error {
// 	return nfcVde.err
// }

// // CValidate  This does validate the notification create request
// func (nfcVde *nfcValidation) CValidate() {
// 	reqBody := nfcVde.nRequest.Body

// 	// Add required validation on validator pool
// 	var validator = [...]func(*nfcValidation, []Parameter){
// 		func(n *nfcValidation, param []Parameter) { n.fieldValidation(reqBody) },
// 	}

// 	// Validate the given notification against every single circumstance,
// 	// The validation will be skipped at any time if anyone fail to meet the conditions
// 	for i := range validator {
// 		if nfcVde.IsValid() == false {
// 			break
// 		}
// 		validator[i](nfcVde, []Parameter{})
// 	}
// 	nfcVde.Log.Infoln("Call return back from the Notification create validation")
// }

// // RValidate  This does validate the notification read request
// func (nfcVde *nfcValidation) RValidate() {
// 	// Add requires validation on validator pool
// 	var validator = [...]func(*nfcValidation, []Parameter){
// 		func(s *nfcValidation, param []Parameter) {
// 			s.validateNFCIDFormate(nfcVde.nRequest.Vars["notificationID"])
// 		},
// 	}

// 	// Validate the given notification against every single circumstance,
// 	// The validation will be skipped at any time if anyone fail to meet the conditions
// 	for i := range validator {
// 		if nfcVde.IsValid() == false {
// 			break
// 		}
// 		validator[i](nfcVde, []Parameter{})
// 	}
// 	nfcVde.Log.Infoln("Call return back from the notification read validation")
// }

// // DValidate  This does validate the Notification delete request
// func (nfcVde *nfcValidation) DValidate() {
// 	// Add requires validation on validator pool
// 	var validator = [...]func(*nfcValidation, []Parameter){
// 		func(s *nfcValidation, param []Parameter) {
// 			s.validateNFCIDFormate(nfcVde.nRequest.Vars["notificationID"])
// 		},
// 	}

// 	// Validate the given Notification against every single circumstance,
// 	// The validation will be skipped at any time if anyone fail to meet the conditions
// 	for i := range validator {
// 		if nfcVde.IsValid() == false {
// 			break
// 		}
// 		validator[i](nfcVde, []Parameter{})
// 	}
// 	nfcVde.Log.Infoln("Call return back from the Notification delete validation")
// }

// // LValidate  This does validate the Notification list request
// func (nfcVde *nfcValidation) LValidate() {
// 	// Notification requires validation on validator pool
// 	var validator = [...]func(*nfcValidation, []Parameter){
// 		func(n *nfcValidation, param []Parameter) {
// 			n.listPageAndSize(nfcVde.nRequest.QueryValue)
// 		},
// 	}
// 	// Validate the given Notification against every single circumstance,
// 	// The validation will be skipped at any time if anyone gets fail
// 	for i := range validator {
// 		if nfcVde.IsValid() == false {
// 			break
// 		}
// 		validator[i](nfcVde, []Parameter{})
// 	}
// 	nfcVde.Log.Infoln("Call return back from the Notification list validation")
// }

// // UValidate  This does validate the Notification update request
// func (nfcVde *nfcValidation) UValidate() {
// 	reqBody := nfcVde.nRequest.Body
// 	// Add requires validation on validator pool
// 	var validator = [...]func(*nfcValidation, []Parameter){
// 		func(s *nfcValidation, param []Parameter) { s.fieldValidation(reqBody) },
// 		func(s *nfcValidation, param []Parameter) {
// 			s.validateNFCIDFormate(nfcVde.nRequest.Vars["notificationID"])
// 		},
// 	}

// 	// Validate the given configuration against every single circumstance,
// 	// The validation will be skipped at any time if anyone fail to meet the conditions
// 	for i := range validator {
// 		if nfcVde.IsValid() == false {
// 			break
// 		}
// 		validator[i](nfcVde, []Parameter{})
// 	}
// 	nfcVde.Log.Infoln("Call return back from the notification update validation")
// }
