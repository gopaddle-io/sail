package validation

// import (
// 	"gopaddle/microservicetemplate/directory"
// 	"gopaddle/microservicetemplate/notification/ioe/err"
// 	"gopaddle/microservicetemplate/notification/ioe/request"
// 	"gopaddle/microservicetemplate/notification/misc"
// 	"regexp"
// 	"strconv"
// 	"strings"

// 	"github.com/go-playground/locales/en"
// 	ut "github.com/go-playground/universal-translator"
// 	validator "gopkg.in/go-playground/validator.v9"
// )

// var myRegExp = map[string]string{
// 	"name": "^[a-z0-9-]+$",
// 	"id":   "^[a-z0-9_]+$",
// }

// // NewValidateContext Factory method for all kind of resource validation
// func NewValidateContext(baseCxt misc.BaseContext, resource interface{}) nfcValidation {
// 	trans, vde := buildValidationClient()
// 	switch resource.(type) {
// 	case request.NfcRequest:
// 		nfs := nfcValidation{
// 			AbstractValidation: AbstractValidation{
// 				BaseContext: baseCxt,
// 				vde: struct {
// 					v     *validator.Validate
// 					trans ut.Translator
// 				}{
// 					v:     vde,
// 					trans: trans,
// 				},
// 			},
// 			nRequest: resource.(request.NfcRequest),
// 		}
// 		nfs.AbstractValidation.ValidateInterface = &nfs
// 		nfs.registerCustomValidation()
// 		return nfs

// 	}
// 	return nfcValidation{}
// }

// // This generic function is not validate anything

// // CValidate It validates resource create's request
// func (absVde *AbstractValidation) CValidate() {
// 	absVde.Log.Debugln("Default create validator get invoked")
// }

// // // SValidate It validates resource dao's request
// // func (absVde *AbstractValidation) SValidate() {
// // 	absVde.Log.Debugln("Default create validator get invoked")
// // }

// // RValidate It validates resource read's request
// func (absVde *AbstractValidation) RValidate() {
// 	absVde.Log.Debugln("Default read validator get invoked")
// }

// // UValidate It validates resource update's request
// func (absVde *AbstractValidation) UValidate() {
// 	absVde.Log.Debugln("Default update validator get invoked")
// }

// // DValidate It validates resource delete's request
// func (absVde *AbstractValidation) DValidate() {
// 	absVde.Log.Debugln("Default delete validator get invoked")
// }

// // LValidate It validates delete list's request
// func (absVde *AbstractValidation) LValidate() {
// 	absVde.Log.Debugln("Default list validator get invoked")
// }

// // IsValid Check if error happens during every validation
// func (nfcVde *nfcValidation) IsValid() bool {
// 	if nfcVde.GetError() == nil {
// 		return true
// 	}

// 	return false
// }

// func (absVde *AbstractValidation) registerCustomValidation() {
// 	// Custom validation
// 	absVde.vde.v.RegisterValidation("myreg", absVde.MyRegExp)
// }

// // buildValidationClient Customized error message
// func buildValidationClient() (ut.Translator, *validator.Validate) {
// 	en := en.New()
// 	uni := ut.New(en, en)
// 	validate := validator.New()
// 	trans, _ := uni.GetTranslator("en")

// 	validate.RegisterTranslation("required", trans, func(ut ut.Translator) error {
// 		return ut.Add("required", directory.ErrorFmt("all", "MISSING_FIELD", "{0}"), true)
// 	}, func(ut ut.Translator, fe validator.FieldError) string {
// 		t, _ := ut.T("required", fe.StructNamespace())
// 		return t
// 	})

// 	validate.RegisterTranslation("myreg", trans, func(ut ut.Translator) error {
// 		return ut.Add("myreg", "Invalid value encountered in '{0}'. The value should be '{1}'", true)
// 	}, func(ut ut.Translator, fe validator.FieldError) string {
// 		t, _ := ut.T("myreg", fe.StructNamespace(), myRegExp[fe.Param()])
// 		return t
// 	})

// 	validate.RegisterTranslation("oneof", trans, func(ut ut.Translator) error {
// 		return ut.Add("oneof", "Invalid value encountered in '{0}'. The value should be one of list '[{1}]'", true)
// 	}, func(ut ut.Translator, fe validator.FieldError) string {
// 		t, _ := ut.T("oneof", fe.StructNamespace(), strings.Join(strings.Split(fe.Param(), " "), ", "))
// 		return t
// 	})

// 	validate.RegisterTranslation("len", trans, func(ut ut.Translator) error {
// 		return ut.Add("len", "Invalid value encountered in '{0}'. The length of value should be '{1}'", true)
// 	}, func(ut ut.Translator, fe validator.FieldError) string {
// 		t, _ := ut.T("len", fe.StructNamespace(), fe.Param())
// 		return t
// 	})

// 	validate.RegisterTranslation("hexadecimal", trans, func(ut ut.Translator) error {
// 		return ut.Add("hexadecimal", "Invalid value encountered in '{0}'. The value should be in hexadecimal format", true)
// 	}, func(ut ut.Translator, fe validator.FieldError) string {
// 		t, _ := ut.T("hexadecimal", fe.StructNamespace(), fe.Param())
// 		return t
// 	})

// 	return trans, validate
// }

// // listPageAndSize Check if page and size query are valid one
// func (absVde *AbstractValidation) listPageAndSize(queryValue map[string][]string) bool {
// 	page, _ := strconv.Atoi(queryValue["page"][0])
// 	size, _ := strconv.Atoi(queryValue["size"][0])

// 	if page < 0 || size < 0 {
// 		absVde.Log.Errorln("Page and Size can not be negative number: ", page, size)
// 		absVde.err = err.NewBadRequest(directory.ErrorFmt("notification", "PAGESIZE_NEGAVE", page, size))
// 		return false
// 	}

// 	// Validate the pagination 'page' length
// 	if page > request.PageLengthLimit {
// 		absVde.Log.Errorln("Requesting page length has been exceeded:", page)
// 		absVde.err = err.NewBadRequest(directory.ErrorFmt("notification", "PPAGE_LIMIT", page, request.PageLengthLimit))
// 		return false
// 	}

// 	// Validate the pagination 'size' lenght
// 	if size > request.SizeLengthLimit {
// 		absVde.Log.Errorln("Requesting size length has been exceeded:", size)
// 		absVde.err = err.NewBadRequest(directory.ErrorFmt("notification", "PSIZE_LIMIT", size, request.SizeLengthLimit))
// 		return false
// 	}
// 	return true
// }

// // MyRegExp It does validates custom regular validation
// func (absVde *AbstractValidation) MyRegExp(fl validator.FieldLevel) bool {

// 	value := fl.Field().String()
// 	r, e := regexp.Compile(myRegExp[fl.Param()])
// 	if e != nil {
// 		absVde.Log.Errorln("Thers is a problem on custom validation: ", e.Error())
// 		return false
// 	}

// 	if !r.MatchString(value) {
// 		absVde.Log.Errorf("Failed on custom validation reg: '%s' with value: '%s'", myRegExp[fl.Param()], value)
// 		return false
// 	}
// 	return true
// }

// // fieldValidation Validate manadate field of notification using lib
// func (absVde *AbstractValidation) fieldValidation(s interface{}) bool {
// 	if e := absVde.vde.v.Struct(s); e != nil {
// 		errs := e.(validator.ValidationErrors)
// 		for _, e := range errs {
// 			errString := e.Translate(absVde.vde.trans)

// 			// Remove root struct name
// 			errString = strings.Replace(errString, "NotificationBody.", "", -1)
// 			absVde.err = err.NewBadRequest(errString)
// 			absVde.Log.Errorf("Failed on required field validation: %s", errString)
// 			return false
// 		}
// 	}
// 	return true
// }

// // validateNFCIDFormate Ensure Notification id is valid formate only during requesting
// func (absVde *AbstractValidation) validateNFCIDFormate(nfcID string) bool {
// 	if len(nfcID) != 39 {
// 		absVde.Log.Errorf("Requesting Notification id is invalid format: '%s' and length '%d'", nfcID, len(nfcID))
// 		absVde.err = err.NewBadRequest(directory.ErrorFmt("notification", "INVALID_NOTIFICATIONID_FMT", nfcID))
// 		return false
// 	}
// 	return true
// }
