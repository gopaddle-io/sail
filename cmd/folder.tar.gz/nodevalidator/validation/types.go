package validation

// import (
// 	"gopaddle/microservicetemplate/notification/ioe/request"
// 	"gopaddle/microservicetemplate/notification/misc"

// 	ut "github.com/go-playground/universal-translator"

// 	validator "gopkg.in/go-playground/validator.v9"
// )

// // Parameter This will pass ,
// // This will be generic parameter receiver, The parameters could be anything
// type Parameter interface{}

// // ValidateInterface CRUD Request validation interface
// type ValidateInterface interface {
// 	// Validate the REST create operation
// 	CValidate()

// 	// Validate the REST read operation
// 	RValidate()

// 	// Validate the REST update operation
// 	UValidate()

// 	// Validate the REST delete operation
// 	DValidate()

// 	// Validate the REST list operation
// 	LValidate()
// 	IsValid() bool
// 	GetError() error
// }

// // AbstractValidation Base validation context
// type AbstractValidation struct {
// 	err error
// 	//Transaction

// 	// This does validate if required fields are there
// 	vde struct {
// 		v     *validator.Validate
// 		trans ut.Translator
// 	}
// 	// To handle the Database dependency
// 	// This will mock the Database connectivity during unit test
// 	misc.BaseContext

// 	ValidateInterface
// }

// type nfcValidation struct {
// 	nRequest request.NfcRequest

// 	AbstractValidation
// }
