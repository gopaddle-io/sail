package nodevalidator

import (
	"gopaddle/nodechecker/nodevalidator/ctrl"
	"gopaddle/nodechecker/nodevalidator/misc"
	"gopaddle/nodechecker/util"
	"gopaddle/nodechecker/util/log"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

// Register which register external notification channels like pagerDuty, SNS ...
// with users gopaddle account.
// func Register(rw http.ResponseWriter, req *http.Request) {
// 	requestID := util.NewRequestID()
// 	defer func() {
// 		if r := recover(); r != nil {
// 			e := misc.PanicHandler(r, requestID)
// 			rw.WriteHeader(e.Code)
// 			rw.Write([]byte(e.Response))
// 		}
// 	}()
// 	vars := mux.Vars(req)
// 	accID := vars["accountID"]
// 	log.Log(accID, "module:notification", "requestID:"+requestID).Infoln("Requsting to register new notification channel")
// 	response := ctrl.RegisterNotificationCtrl(vars, req, requestID)
// 	rw.WriteHeader(response.Code)
// 	rw.Write([]byte(response.Response))
// 	log.Log(accID, "module:notification", "requestID:"+requestID, "code:"+strconv.Itoa(response.Code)).Infoln("Requsting to register new notification channel completed")
// }

// Read notification
func Read(rw http.ResponseWriter, req *http.Request, next http.HandlerFunc) {
	requestID := util.NewRequestID()
	defer func() {
		if r := recover(); r != nil {
			e := misc.PanicHandler(r, requestID)
			rw.WriteHeader(e.Code)
			rw.Write([]byte(e.Response))
		}
	}()
	vars := mux.Vars(req)
	accID := vars["accountID"]
	log.Log(accID, "module:nodevalidator", "requestID:"+requestID).Infoln("Requsting get nodevalidator")
	response := ctrl.ReadNodeValidatorCtrl(vars, req, requestID)
	rw.WriteHeader(response.Code)
	rw.Write([]byte(response.Response))
	log.Log(accID, "module:nodevalidator", "requestID:"+requestID, "code:"+strconv.Itoa(response.Code)).Infoln("Read a notification requesting call is end")
}

// Update notification
// func Update(rw http.ResponseWriter, req *http.Request) {
// 	requestID := util.NewRequestID()
// 	defer func() {
// 		if r := recover(); r != nil {
// 			e := misc.PanicHandler(r, requestID)
// 			rw.WriteHeader(e.Code)
// 			rw.Write([]byte(e.Response))
// 		}
// 	}()

// 	vars := mux.Vars(req)
// 	accID := vars["accountID"]
// 	log.Log(accID, "module:notification", "requestID:"+requestID).Infoln("Requsting get notification")
// 	response := ctrl.UpdateNotificationCtrl(vars, req, requestID)
// 	rw.WriteHeader(response.Code)
// 	rw.Write([]byte(response.Response))
// 	log.Log(accID, "module:notification", "requestID:"+requestID, "code:"+strconv.Itoa(response.Code)).Infoln("Read a notification requesting call is end")
// }

// // Delete notification
// func Delete(rw http.ResponseWriter, req *http.Request) {
// 	requestID := util.NewRequestID()
// 	defer func() {
// 		if r := recover(); r != nil {
// 			e := misc.PanicHandler(r, requestID)
// 			rw.WriteHeader(e.Code)
// 			rw.Write([]byte(e.Response))
// 		}
// 	}()

// 	vars := mux.Vars(req)
// 	log.Log(vars["accountID"], "module:notification", "requestID:"+requestID).Infoln("Requsting delete notification: " + vars["notificationID"])
// 	response := ctrl.DeleteNotificationCtrl(vars, req, requestID)
// 	rw.WriteHeader(response.Code)
// 	rw.Write([]byte(response.Response))
// 	log.Log(vars["accountID"], "module:notification", "requestID:"+requestID, "code:"+strconv.Itoa(response.Code)).Infoln("Delete a notification requesting call is end")
// }

// // List notification
// func List(rw http.ResponseWriter, req *http.Request) {
// 	requestID := util.NewRequestID()
// 	defer func() {
// 		if r := recover(); r != nil {
// 			e := misc.PanicHandler(r, requestID)
// 			rw.WriteHeader(e.Code)
// 			rw.Write([]byte(e.Response))
// 		}
// 	}()

// 	vars := mux.Vars(req)
// 	log.Log(vars["accountID"], "module:notification", "requestID:"+requestID).Infoln("Requsting list all notifications")
// 	response := ctrl.ListNotificationCtrl(vars, req, requestID)
// 	rw.WriteHeader(response.Code)
// 	rw.Write([]byte(response.Response))
// 	log.Log(vars["accountID"], "module:notification", "requestID:"+requestID, "code:"+strconv.Itoa(response.Code)).Infoln("list the notifications requesting call is end")

// }
