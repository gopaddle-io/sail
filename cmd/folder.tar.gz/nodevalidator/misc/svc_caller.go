package misc

// // GetUser -
// func (miscHandle *MiscHandle) GetUser() bhttp.HTTPResponse {
// 	url := directory.Endpoint("user.ep", "api/"+miscHandle.AccountID+"/user")
// 	miscHandle.Log.Debugf("URL to get user details: %s", url)
// 	conn := *bhttp.NewHTTPConnection(url)
// 	resp := bhttp.Retry(miscHandle.HTTP.Get, conn, miscHandle.Log).WithDelay(40).WithAttempt(4).Do()
// 	return resp
// }
