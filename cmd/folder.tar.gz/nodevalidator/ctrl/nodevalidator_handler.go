package ctrl

import (
	"errors"
	"gopaddle/nodechecker/nodevalidator/dao"
	"gopaddle/nodechecker/util/json"
)

func ifExist(val *string) string {
	if val != nil {
		return *val
	}
	return ""
}

// func (nvCxt *nfcContext) RegisterNotification() (string, error) {
// 	req := nvCxt.NRequest.Body
// 	nvDao, daoError := dao.NewNotificationDAO(nvCxt.Log, nvCxt.NRequest.Vars["accountID"])
// 	if daoError != nil {
// 		nvCxt.Log.Errorln("Failed on Registering Notification Channel due to previous error")
// 		return "", daoError
// 	}

// 	e := tools.CopyStruct(req, &nvDao)
// 	if e != nil {
// 		nvCxt.Log.Errorf("Failed on copying Notification Request to Notification DAO object: %s", e.Error())
// 		return "", err.NewInternalException("Failed on copying Notification Request")
// 	}

// 	if e = nvCxt.DS.Write(nvDao); e != nil {
// 		return "", e
// 	}

// 	response := json.New()
// 	response.Put("message", "Notification Channel created successfully")
// 	response.Put("notificaitonID", nvDao.ID)
// 	response.Put("requestID", nvCxt.RequestID)
// 	nvCxt.Log.Infoln("Created a new Notification Channel")
// 	return response.ToString(), nil
// }

// ReadNodeValidator It does reads a Notification
func (nvCxt *nvContext) ReadNodeValidator() (string, error) {
	response := json.New()
	nvDao := dao.NodeValidatorDAO{}
	if errs := nvCxt.DS.Read(&nvDao, dao.Parameter{"nodeName": nvCxt.NRequest.QueryValue["nodeName"][0]}); errs != nil {
		return "", errs
	}

	if nvDao.NodeName == nvCxt.NRequest.QueryValue["nodeName"][0] {
		response.Put("message", "requested service deployed on the same node")
		return response.ToString(), nil
	} else {
		return "", errors.New("requested service may be deployed on the different node")
	}
	// fmtResult.Response.RequestID = nvCxt.RequestID
	return response.ToString(), nil
}

// // ListNotification It does list the all notificaiton
// func (nvCxt *nfcContext) ListNotification() (string, error) {
// 	var nfcDAO = dao.NotificationDAO{}
// 	var nfcDAOArr = []dao.NotificationDAO{}
// 	var condition = make(map[string][]map[string]interface{})

// 	result, qErr := nvCxt.DS.Query(&nfcDAO, condition, dao.Parameter{
// 		"page": nvCxt.NRequest.QueryValue["page"][0], "size": nvCxt.NRequest.QueryValue["size"][0], "field": "name",
// 	})
// 	if qErr != nil {
// 		return "", qErr
// 	}

// 	// This total count helps to prepare pagination
// 	var paginationCount *int
// 	if nvCxt.NRequest.QueryValue["page"][0] == "1" {

// 		// To clear previous assignment
// 		paginationCount = util.GetPtrInt(0)
// 		if e := nvCxt.getPaginationCount(make(map[string][]map[string]interface{}), paginationCount); e != nil {
// 			return "", e
// 		}
// 	}

// 	// Convert generic type ([]interface{}) to dao model
// 	if e := tools.CopyStruct(result, &nfcDAOArr); e != nil {
// 		nvCxt.Log.Errorf("Failed on notificaiton channel result preparation: %s", e.Error())
// 		return "", err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
// 	}

// 	return nvCxt.prepareNotificationRS(paginationCount, nfcDAOArr)
// }

// // DeleteNotification It does delete a notification
// func (nvCxt *nfcContext) DeleteNotification() (string, error) {
// 	nvDao := dao.NotificationDAO{}
// 	errs := nvCxt.DS.Delete(&nvDao, dao.Parameter{"key": "id", "value": nvCxt.NRequest.Vars["notificationID"]})
// 	if errs != nil {
// 		nvCxt.Log.Errorln("Failed on deleting notification due to previous error")
// 		return "", errs
// 	}

// 	nvCxt.Log.Infoln("Deleted a notification with: " + nvDao.Name)
// 	response := json.New()
// 	response.Put("message", "Notification Channel deleted successfully")
// 	response.Put("notificationID", nvCxt.NRequest.Vars["notificationID"])
// 	response.Put("requestID", nvCxt.RequestID)
// 	return response.ToString(), nil
// }

// func (nvCxt *nfcContext) getPaginationCount(condition map[string][]map[string]interface{}, paginationCount *int) error {
// 	var nvDao = dao.NotificationDAO{}

// 	// To clear previous assignment
// 	totalCount, e := nvCxt.DS.GetTotal(&nvDao, condition, dao.Parameter{})
// 	if e != nil {
// 		return e
// 	}

// 	*paginationCount = totalCount
// 	return nil
// }

// // It does prepares notification result set
// func (nvCxt *nfcContext) prepareNotificationRS(paginationCount *int, nfcDaoArr []dao.NotificationDAO) (string, error) {
// 	var resultSet response.NotificationRespList

// 	// Populate set of config
// 	for _, record := range nfcDaoArr {
// 		fmtRecord := parser.NewNotificationFormatter(nvCxt.Log)
// 		if e := fmtRecord.Transform(record); e != nil {
// 			return "", e
// 		}

// 		resultSet.Notifications = append(resultSet.Notifications, *fmtRecord.Response)
// 	}
// 	fmtParser := parser.NewNotificationFormatter(nvCxt.Log)
// 	resultSet.Count = util.GetPtrInt(len(nfcDaoArr))
// 	resultSet.RequestID = nvCxt.RequestID
// 	resultSet.PaginationCount = paginationCount
// 	return fmtParser.ToStringWithValues(resultSet)
// }

// // UpdateCodeBaseAuth -
// func (nvCxt *nfcContext) UpdateNotification() (string, error) {
// 	req := nvCxt.NRequest.Body

// 	nvDao := dao.NotificationDAO{}
// 	if errs := nvCxt.DS.Read(&nvDao, dao.Parameter{"key": "id", "value": nvCxt.NRequest.Vars["notificationID"]}); errs != nil {
// 		return "", errs
// 	}
// 	e := tools.CopyStruct(req, &nvDao)
// 	if e != nil {
// 		nvCxt.Log.Errorf("Failed on copying notification Request to notification DAO object: %s", e.Error())
// 		return "", err.NewInternalException("Failed on copying notification Request")
// 	}

// 	// Updated object with latest request values

// 	if e := nvCxt.DS.Update(&nvDao, dao.Parameter{"key": "id", "value": nvCxt.NRequest.Vars["notificationID"]}); e != nil {
// 		nvCxt.Log.Errorln("Failed on updating notification due to previous error")
// 		return "", e
// 	}

// 	response := json.New()
// 	response.Put("message", "Codebase CodeBaseAuth updated successfully")
// 	response.Put("notificationID", nvDao.ID)
// 	response.Put("requestID", nvDao.RequestID)
// 	return response.ToString(), nil
// }
