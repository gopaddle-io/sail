package ctrl

import (
	"gopaddle/nodechecker/nodevalidator/dao"
	"gopaddle/nodechecker/nodevalidator/ioe/request"
	"gopaddle/nodechecker/nodevalidator/misc"
	"gopaddle/nodechecker/util/bhttp"

	"github.com/sirupsen/logrus"
)

type nvContext struct {
	NRequest request.NvRequest
	misc.BaseContext
}

// NewnfsContext notification root context
func NewnvContext(log *logrus.Entry, requestID string) *nvContext {
	nvCxt := nvContext{}
	nvCxt.BaseContext.RequestID = requestID
	nvCxt.BaseContext.Log = log
	nvCxt.BaseContext.DS = dao.NewDataStore(log)
	nvCxt.NRequest.QueryValue = make(request.URLQuery)
	nvCxt.BaseContext.HTTP = bhttp.NewHTTPCaller(log)
	nvCxt.MiscHandle = misc.MiscHandle{InternalContext: nvCxt.InternalContext, RequestID: requestID}
	return &nvCxt
}

type Error struct {
	Message string `json:"message"`

	RequestID string `json:"requestID"`
}
