package ctrl

import (
	gson "encoding/json"
	"fmt"
	"gopaddle/nodechecker/nodevalidator/dao"
	"gopaddle/nodechecker/nodevalidator/ioe/err"
	"gopaddle/nodechecker/nodevalidator/misc"
	"gopaddle/nodechecker/nodevalidator/parser"
	"gopaddle/nodechecker/util/db"
	"gopaddle/nodechecker/util/json"
	"gopaddle/nodechecker/util/log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

// // RegisterNotificationCtrl to register new notification channels under users gopaddle account
// func RegisterNodeCtrl(vars map[string]string, req *http.Request, requestID string) misc.Response {
// 	log := log.Log(vars["accountID"], "module:notification", "requestID:"+requestID)

// 	// Create a notification context
// 	nfcCxt := NewnfsContext(log, requestID, vars["accountID"])
// 	nfcCxt.NRequest.Vars = vars

// 	// Parse the given request and converted into internal struct
// 	p := parser.NewParser(nfcCxt.BaseContext, *req)
// 	if e := p.Parse(&nfcCxt.NRequest.Body); e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	// Validate requested json
// 	v := validation.NewValidateContext(nfcCxt.BaseContext, nfcCxt.NRequest)
// 	v.CValidate()

// 	if !v.IsValid() {
// 		eFmt := err.FmtError(v.GetError())
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	// Initiated actual process
// 	resp, e := nfcCxt.RegisterNotification()
// 	if e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}
// 	return misc.Response{Code: 200, Response: resp}
// }

// ReadNodeValidatorCtrl It handles read a nodechecker
func ReadNodeValidatorCtrl(vars map[string]string, req *http.Request, requestID string) misc.Response {
	log := log.Log(vars["accountID"], "module:nodevalidator", "requestID:"+requestID)

	// read a nodechecker context
	nvCxt := NewnvContext(log, requestID)
	nvCxt.NRequest.Vars = vars

	p := parser.NewParser(nvCxt.BaseContext, *req)
	if e := p.QueryParse(&nvCxt.NRequest.QueryValue); e != nil {
		eFmt := err.FmtError(e)
		return misc.Response{Code: eFmt.GetCode(), Response: nvCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
	}
	// Validate requested json
	// v := validation.NewValidateContext(nvCxt.BaseContext, nvCxt.NRequest)
	// v.RValidate()

	// if !v.IsValid() {
	// 	eFmt := err.FmtError(v.GetError())
	// 	return misc.Response{Code: eFmt.GetCode(), Response: nvCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
	// }

	// Initiated actual process
	resp, e := nvCxt.ReadNodeValidator()
	if e != nil {
		//eFmt := err.FmtError(e)
		return misc.Response{Code: 500, Response: nvCxt.MiscHandle.BuildHTTPErrorJSON(e.Error(), requestID)}
	}
	return misc.Response{Code: 200, Response: resp}
}

// // ListNotificationCtrl It handles notification list calls
// func ListNotificationCtrl(vars map[string]string, req *http.Request, requestID string) misc.Response {
// 	log := log.Log(vars["accountID"], "module:service", "requestID:"+requestID)

// 	// Create a notification context
// 	nfcCxt := NewnfsContext(log, requestID, vars["accountID"])
// 	nfcCxt.NRequest.Vars = vars

// 	// Parse the given request and converted into internal struct
// 	p := parser.NewParser(nfcCxt.BaseContext, *req)
// 	if e := p.QueryParse(&nfcCxt.NRequest.QueryValue); e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}
// 	nfcCxt.NRequest.Vars = vars

// 	// Validate requested json
// 	v := validation.NewValidateContext(nfcCxt.BaseContext, nfcCxt.NRequest)
// 	v.LValidate()

// 	if !v.IsValid() {
// 		eFmt := err.FmtError(v.GetError())
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	// Initiated actual process
// 	resp, e := nfcCxt.ListNotification()
// 	if e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}
// 	return misc.Response{Code: 200, Response: resp}
// }

// // DeleteNotificationCtrl It will handle Notification channel delete
// func DeleteNotificationCtrl(vars map[string]string, req *http.Request, requestID string) misc.Response {
// 	log := log.Log(vars["accountID"], "module:service", "requestID:"+requestID)

// 	// Create a notification context
// 	nfcCxt := NewnfsContext(log, requestID, vars["accountID"])
// 	nfcCxt.NRequest.Vars = vars

// 	// Validate requested json
// 	v := validation.NewValidateContext(nfcCxt.BaseContext, nfcCxt.NRequest)
// 	v.DValidate()

// 	if !v.IsValid() {
// 		eFmt := err.FmtError(v.GetError())
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	resp, e := nfcCxt.DeleteNotification()
// 	if e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}
// 	return misc.Response{Code: 200, Response: resp}
// }

// // UpdateNotificationCtrl It does updates an new notification
// func UpdateNotificationCtrl(vars map[string]string, req *http.Request, requestID string) misc.Response {
// 	log := log.Log(vars["accountID"], "module:build", "requestID:"+requestID)

// 	// Create a notification context
// 	nfcCxt := NewnfsContext(log, requestID, vars["accountID"])
// 	nfcCxt.NRequest.Vars = vars

// 	// Parse the given request and converted into internal struct
// 	// Request body parser
// 	p := parser.NewParser(nfcCxt.BaseContext, *req)
// 	if e := p.Parse(&nfcCxt.NRequest.Body); e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	// Validate requested json
// 	v := validation.NewValidateContext(nfcCxt.BaseContext, nfcCxt.NRequest)
// 	v.UValidate()

// 	if !v.IsValid() {
// 		eFmt := err.FmtError(v.GetError())
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	// Initiated actual process
// 	resp, e := nfcCxt.UpdateNotification()
// 	if e != nil {
// 		eFmt := err.FmtError(e)
// 		return misc.Response{Code: eFmt.GetCode(), Response: nfcCxt.MiscHandle.BuildHTTPErrorJSON(eFmt.Error(), requestID)}
// 	}

// 	return misc.Response{Code: 200, Response: resp}
// }

func SetNodeEnv() {
	var nv dao.NodeValidatorDAO
	nv.NodeName = os.Getenv("NODE_NAME")
	fmt.Println("node name is ", nv.NodeName)
	if nv.NodeName == "" {
		fmt.Printf("node name is empty")
		os.Exit(0)
	}
	nv.UpdatedTime = time.Now().UTC().String()
	nv.CreatedTime = time.Now().UTC().String()
	query := make(map[string][]map[string]interface{})
	count, e := db.Instance().Count("nodevalidator", query)
	if e != nil {
		fmt.Printf("Failed on getting nodevalidator channel total count: '%s' error with '%s'", nv.NodeName, e.Error())
		return
	}
	if count == 1 {
		accMap := map[string]interface{}{"nodeName": nv.NodeName}
		query["$and"] = append(query["$and"], accMap)
		_, e := db.Instance().ReadOne("nodevalidator", query)
		if e != nil {
			fmt.Printf("Failed on reading notification channel: '%s' error with '%s'", e.Error())
			if strings.Contains(e.Error(), "not found") {
				fmt.Println("nodeChecker deployed on different node")
				os.Exit(0)
			}
		}
		fmt.Println("nodevalidator already exists")
		return
	} else if count > 1 {
		fmt.Println("nodevalidator has too many nodenames")
		os.Exit(0)
	}
	if e = db.Instance().Create("nodevalidator", nv); e != nil {
		fmt.Printf("Failed on writting nodevalidator: '%s' error with '%s'", nv.NodeName, e.Error())
	}
}

type timeval struct {
	LaunchTime string `bson:"launchTime" json:"launchTime"`
}

func SetValidity(validity string) {
	fmt.Println(" setvalidity validity is ", validity)
	tv := timeval{}
	dateArgs := strings.Split(validity, "-")
	var d, m, y int
	if len(dateArgs) == 3 {
		y, _ = strconv.Atoi(dateArgs[0])
		m, _ = strconv.Atoi(dateArgs[1])
		d, _ = strconv.Atoi(dateArgs[2])
	} else {
		fmt.Println("Invalid date validity argument")
		os.Exit(0)
	}
	loc, _ := time.LoadLocation("UTC")
	pt := time.Now().In(loc)
	tv.LaunchTime = pt.AddDate(y, m, d).String()
	query := make(map[string][]map[string]interface{})
	count, e := db.Instance().Count("timevalidator", query)
	if e != nil {
		fmt.Printf("Failed on getting timevalidator channel total count: error with '%s'", e.Error())
		return
	}
	if count == 1 {
		d, e := db.Instance().ReadOne("timevalidator", query)
		if e != nil {
			fmt.Printf("Failed on reading notification channel: '%s' error with '%s'", e.Error())
			if strings.Contains(e.Error(), "not found") {
				fmt.Println("nodeChecker deployed on different node")
				os.Exit(0)
			}
		}
		str, _ := gson.Marshal(d)
		tjsn := json.ParseString(string(str))
		launchtime := tjsn.GetString("launchTime")
		if launchtime != "" {
			valtime := TimeParse(launchtime)
			if valtime.Before(time.Now().In(loc)) {
				fmt.Printf("gopaddle licence time expired")
				os.Exit(0)
			}
			go TimeValidation()
			return
		} else {
			fmt.Printf("time validator is empty")
			os.Exit(0)
		}
	} else if count > 1 {
		fmt.Println("two many times for validation")
		os.Exit(0)
	}
	if e = db.Instance().Create("timevalidator", tv); e != nil {
		fmt.Printf("Failed on writting timevalidator:  error with '%s'", e.Error())
	}
	go TimeValidation()
}
func TimeValidation() {
	for {
		loc, _ := time.LoadLocation("UTC")
		query := make(map[string][]map[string]interface{})
		count, e := db.Instance().Count("timevalidator", query)
		if e != nil {
			fmt.Printf("Failed on getting timevalidator channel total count: error with '%s'", e.Error())
			return
		}
		if count == 1 {
			d, e := db.Instance().ReadOne("timevalidator", query)
			if e != nil {
				fmt.Printf("Failed on reading notification channel: '%s' error with '%s'", e.Error())
				if strings.Contains(e.Error(), "not found") {
					fmt.Println("nodeChecker deployed on different node")
					os.Exit(0)
				}
			}
			str, _ := gson.Marshal(d)
			tjsn := json.ParseString(string(str))
			launchtime := tjsn.GetString("launchTime")
			if launchtime != "" {
				valtime := TimeParse(launchtime)
				if valtime.Before(time.Now().In(loc)) {
					fmt.Printf("gopaddle licence time expired")
					os.Exit(0)
				}
			} else {
				fmt.Printf("time validator is empty")
				os.Exit(0)
			}
		} else if count > 1 {
			fmt.Println("two many times for validation")
			os.Exit(0)
		}
		timer := time.NewTimer(time.Hour * 2)
		<-timer.C
	}
}
func GetTimeString() string {
	loc, _ := time.LoadLocation("UTC")
	now := time.Now().In(loc).Format("2006-01-02 15:04:05.999999999 -0700 UTC")
	return now
}
func TimeParse(ti string) time.Time {
	t, err := time.Parse("2006-01-02 15:04:05.999999999 -0700 UTC", ti)
	if err != nil {
		fmt.Println(err)
	}
	return t
}
