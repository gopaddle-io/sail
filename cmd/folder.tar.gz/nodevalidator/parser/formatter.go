package parser

import (
	"encoding/json"
	"gopaddle/nodechecker/directory"
	"gopaddle/nodechecker/nodevalidator/dao"
	"gopaddle/nodechecker/nodevalidator/ioe/err"
	"gopaddle/nodechecker/nodevalidator/ioe/response"
	"gopaddle/nodechecker/util/tools"

	"github.com/sirupsen/logrus"
)

// Formatter It is a default translator or base to handle all kind response
type Formatter struct {
	log    *logrus.Entry
	result interface{}
}

type nvFormatter struct {
	Formatter
	Response *response.NodeValidator
}

// NewNotificationFormatter Notification formatter initiator
func NewNotificationFormatter(log *logrus.Entry) *nvFormatter {
	sf := &nvFormatter{
		Response:  &response.NodeValidator{},
		Formatter: Formatter{log: log},
	}
	return sf
}

// Transform It converts dao into response type
func (nf *nvFormatter) Transform(v dao.NodeValidatorDAO) error {
	if e := tools.CopyStruct(v, nf.Response); e != nil {
		nf.log.Errorln("Failed on preparing output: ", e.Error())
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}

	nf.result = nf.Response
	return nil
}

// ToString Converts response struct to string
func (nf *Formatter) ToString() (string, error) {
	b, e := json.Marshal(nf.result)
	if e != nil {
		nf.log.Errorln("Failed on formatting output: ", e.Error())
		return "", err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return string(b), nil
}

// ToStringWithValues  Converts response struct to string
func (nf *Formatter) ToStringWithValues(v interface{}) (string, error) {
	b, e := json.Marshal(v)
	if e != nil {
		nf.log.Errorln("Failed on formatting output: ", e.Error())
		return "", err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return string(b), nil
}
