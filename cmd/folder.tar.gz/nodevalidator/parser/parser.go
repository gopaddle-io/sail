package parser

import (
	"encoding/base64"
	"encoding/json"
	"gopaddle/nodechecker/directory"
	"gopaddle/nodechecker/nodevalidator/ioe/err"
	"gopaddle/nodechecker/nodevalidator/ioe/request"
	"gopaddle/nodechecker/nodevalidator/misc"
	"io/ioutil"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

// defaultQueryValues Default values for query parameters
var defaultQueryValues = map[string][]string{
	"p": {strconv.Itoa(request.DefaultPageLength)},
	"s": {strconv.Itoa(request.DefaultSizeLength)},
}

var internalNames = map[string]string{
	"p": "page",
	"s": "size",
}

var allowedQuery = []string{"p", "s", "nodeName"}

// PInterface It contains generic parse methods
type PInterface interface {
	Parse(v interface{}) error
	QueryParse(query *request.URLQuery) error
	String() string
}

// Parser It is a default parser or base to handle all kind request
type Parser struct {
	misc.BaseContext
	httpReq      http.Request
	data         []byte
	AllowedQuery []string
}

// NewParser It creates a specific parser based what you selected
// otherwise it creates a default parser
func NewParser(bCxt misc.BaseContext, req http.Request) PInterface {
	p := Parser{}
	p.httpReq = req
	p.BaseContext = bCxt
	p.AllowedQuery = allowedQuery
	return &p
}

// Parse It does parses the request body and converts it into internal struct
func (p *Parser) Parse(v interface{}) error {
	// Request body parser
	data, e := ioutil.ReadAll(p.httpReq.Body)
	if e != nil {
		p.Log.Errorln("Could not read the request body from stream: ", e.Error())
		return err.NewInternalException(directory.ErrorFmt("All", "SOMETHING_WRONG"))
	}

	// Default unmarshal
	if e := json.Unmarshal([]byte(data), v); e != nil {
		p.Log.Errorln("Could not able to parse the request body: ", e.Error())

		for _, i := range []string{
			".*unmarshal (.*) into.*field (.*) of type (.*)",
			".*unmarshal (.*) into Go value of type (.*)",
		} {

			re := regexp.MustCompile(i)
			submatchall := re.FindStringSubmatch(e.Error())

			if len(submatchall) == 4 {
				// It removes the package name from error message
				exType := strings.Replace(submatchall[3], "request.", "", -1)

				// Known field error
				return err.NewBadRequest(directory.ErrorFmt("All", "UNMARSHAL_ERROR", submatchall[2], exType, submatchall[1]))
			} else if len(submatchall) == 3 {
				// Unknown field error
				return err.NewBadRequest(directory.ErrorFmt("All", "UNKNOWN_UNMARSHAL_ERROR", submatchall[2], submatchall[1]))
			}
		}

		return err.NewBadRequest(e.Error())
	}

	p.data = data
	return nil
}

// QueryParse It does parses the query parameters and applies default values
// for missing parameters
func (p *Parser) QueryParse(query *request.URLQuery) error {
	// Query parameter parser
	reqQuery := p.httpReq.URL.Query()
	tmpQuery := make(request.URLQuery)
	for _, q := range allowedQuery {
		// Converts internal query format
		internalQuery := q
		if internalNames[q] != "" {
			internalQuery = internalNames[q]
		}

		if len(reqQuery[q]) != 0 {
			tmpQuery[internalQuery] = reqQuery[q]
		}
	}

	// Set few default values
	for q, v := range defaultQueryValues {
		internalQuery := q
		if internalNames[q] != "" {
			internalQuery = internalNames[q]
		}

		if p.httpReq.URL.Query().Get(q) == "" {
			tmpQuery[internalQuery] = v
			//p.Log.Warnf("Missing basic query parameter '{%s}'; So default value is going to apply: {%s}", q, v)
		}
	}

	*query = tmpQuery
	return nil
}

func (p *Parser) String() string {
	return base64.StdEncoding.EncodeToString(p.data)
}
