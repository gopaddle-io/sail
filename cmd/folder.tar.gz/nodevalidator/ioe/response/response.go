package response

type NodeValidatorRespList struct {
	PaginationCount *int            `json:"paginationCount,omitempty"`
	NodeValidators  []NodeValidator `json:"nodeValidators,omitempty"`
	Count           *int            `json:"count,omitempty"`
	RequestID       string          `json:"requestID,omitempty"`
}

type NodeValidator struct {
	NodeName string `json:"nodeName,omitempty"`
	// Created Time in UTC format
	CreatedTime string `json:"createdTime,omitempty"`

	// Updated Time in UTC format
	UpdatedTime string `json:"updatedTime,omitempty"`
}
