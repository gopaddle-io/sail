package request

import "net/http"

const (
	Default           = ""
	DefaultPageLength = 1
	DefaultSizeLength = 15

	PageLengthLimit = 1000
	SizeLengthLimit = 25
)

type URLQuery map[string][]string

type BaseRequest struct {
	QueryValue URLQuery

	Headers http.Header

	Vars map[string]string
}

type NvRequest struct {
	BaseRequest
	Body NodeValidatorBody
}

type NodeValidatorBody struct {
	NodeName string `json:"nodeName,omitempty"`
	// Created Time in UTC format
	CreatedTime string `json:"createdTime,omitempty"`

	// Updated Time in UTC format
	UpdatedTime string `json:"updatedTime,omitempty"`
}
