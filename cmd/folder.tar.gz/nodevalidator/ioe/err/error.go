package err

import (
	"fmt"
	"reflect"
)

// ExceptionInterface Wrapper for exception
type ExceptionInterface interface {
	Error() string
	GetCode() int
}

// internalException It holds exception reason and code
type internalException struct {
	code    int
	message string
}

// NewInternalException NewInternalException constructor
func NewInternalException(message string) *internalException {
	return &internalException{code: 500, message: message}
}

// Error To get the exception reason
func (ie *internalException) Error() string { return ie.message }

// GetCode To get the exception code
func (ie *internalException) GetCode() int { return ie.code }

// badRequest It holds exception reason and code
type badRequest struct {
	code    int
	message string
}

// NewBadRequest NewBadRequest constructor
func NewBadRequest(message string) *badRequest {
	return &badRequest{code: 400, message: message}
}

// Error To get the exception reason
func (br *badRequest) Error() string { return br.message }

// GetCode To get the exception code
func (br *badRequest) GetCode() int { return br.code }

// notFound It holds exception reason and code
type notFound struct {
	code    int
	message string
}

// NewNotFound NewNotFound constructor
func NewNotFound(message string) *notFound {
	return &notFound{code: 404, message: message}
}

// Error To get the exception reason
func (nf *notFound) Error() string { return nf.message }

// GetCode To get the exception code
func (nf *notFound) GetCode() int { return nf.code }

// forbidden It holds exception reason and code
type forbidden struct {
	code    int
	message string
}

// NewForbidden NewForbidden constructor
func NewForbidden(message string) *forbidden {
	return &forbidden{code: 403, message: message}
}

// Error To get the exception reason
func (nf *forbidden) Error() string { return nf.message }

// GetCode To get the exception code
func (nf *forbidden) GetCode() int { return nf.code }

// Unknown Error It holds exception reason and code
type unknown struct {
	code    int
	message string
}

// NewUnknown NewUnknown constructor
func NewUnknown(code int, message string) *unknown {
	return &unknown{code: code, message: message}
}

// Error To get the exception reason
func (un *unknown) Error() string { return un.message }

// GetCode To get the exception code
func (un *unknown) GetCode() int { return un.code }

// tooMany Error It holds exception reason and code
type tooManyRequest struct {
	code    int
	message string
}

// NewtooManyRequest NewUnknown constructor
func NewtooManyRequest(message string) *tooManyRequest {
	return &tooManyRequest{code: 429, message: message}
}

// Error To get the exception reason
func (tooMany *tooManyRequest) Error() string { return tooMany.message }

// GetCode To get the exception code
func (tooMany *tooManyRequest) GetCode() int { return tooMany.code }

// FmtError Get error
func FmtError(e interface{}) ExceptionInterface {
	fmt.Println(reflect.TypeOf(e).String())
	switch reflect.TypeOf(e).String() {
	case "*err.badRequest":
		return e.(*badRequest)
	case "*err.notFound":
		return e.(*notFound)
	case "*err.forbidden":
		return e.(*forbidden)
	case "*err.tooManyRequest":
		return e.(*tooManyRequest)
	case "*err.unknown":
		return e.(*unknown)
	}
	return e.(*internalException)
}
