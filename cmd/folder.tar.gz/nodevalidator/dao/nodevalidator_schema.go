package dao

const nodevalidatorTable = "nodevalidator"

type NodeValidatorDAO struct {
	DataStore `bson:",inline"`
	NodeName  string `json:"nodeName,omitempty" bson:"nodeName,omitempty"`
	// Created Time in UTC format
	CreatedTime string `json:"createdTime,omitempty" bson:"createdTime,omitempty"`

	// Updated Time in UTC format
	UpdatedTime string `json:"updatedTime,omitempty" bson:"updatedTime,omitempty"`
}
