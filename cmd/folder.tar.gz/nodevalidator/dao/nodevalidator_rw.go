package dao

import (
	"gopaddle/nodechecker/directory"
	"gopaddle/nodechecker/nodevalidator/ioe/err"
	"gopaddle/nodechecker/util/db"
	"gopaddle/nodechecker/util/tools"
	"strconv"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
)

// Write It writes nodevalidator into db
func (nvDao *NodeValidatorDAO) Write() error {
	nvDao.UpdatedTime = time.Now().UTC().String()
	if e := db.Instance().Create(nodevalidatorTable, nvDao); e != nil {
		nvDao.log.Errorf("Failed on writting nodevalidator: '%s' error with '%s'", nvDao.NodeName, e.Error())
		if strings.Contains(e.Error(), "accountID_1_name_1 dup key") {
			return err.NewBadRequest(directory.ErrorFmt("nodevalidator", "NV_ALREADY_EXIST", nvDao.NodeName))
		}
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return nil
}

// Update It updates notification into db for matched record
func (nvDao *NodeValidatorDAO) Update(params Parameter) error {
	var condition = make(map[string][]map[string]interface{})
	// Added Account ID
	accMap := map[string]interface{}{"accountID": nvDao.NodeName}
	condition["$and"] = append(condition["$and"], accMap)

	// Added ID
	idMap := map[string]interface{}{"nodeName": nvDao.NodeName}
	condition["$and"] = append(condition["$and"], idMap)

	nvDao.UpdatedTime = time.Now().UTC().String()
	nvDao.log.Debugf("Update notification channel, condition: %v and Param: %v", condition, params)
	if e := db.Instance().Update(nodevalidatorTable, condition, nvDao); e != nil {
		nvDao.log.Errorf("Failed on updating notification channel: '%s' error with '%s'", nvDao.NodeName, e.Error())
		if strings.Contains(e.Error(), "not found") {
			return err.NewNotFound(directory.ErrorFmt("notification", "NFC_NOTFOUND", nvDao.NodeName))
		}
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return nil
}

// Delete It does deletes matched document on notification table
func (nvDao *NodeValidatorDAO) Delete(params Parameter) error {
	var condition = make(map[string][]map[string]interface{})
	// Added Account ID
	accMap := map[string]interface{}{"accountID": params["accountID"]}
	condition["$and"] = append(condition["$and"], accMap)

	// Added Key
	keyMap := map[string]interface{}{params["key"]: params["value"]}
	condition["$and"] = append(condition["$and"], keyMap)

	nvDao.log.Debugf("Delete notification channel, Query: %v and Param: %v", condition, params)
	if e := db.Instance().RemoveOne(nodevalidatorTable, condition); e != nil {
		nvDao.log.Errorf("Failed on deleting notification channel: '%s' error with '%s'", params["value"], e.Error())
		if strings.Contains(e.Error(), "not found") {
			return err.NewNotFound(directory.ErrorFmt("notification", "NFC_NOTFOUND", params["value"]))
		}
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return nil
}

// Read it does reads a record from notification
func (nvDao *NodeValidatorDAO) Read(params Parameter) error {
	var condition = make(map[string][]map[string]interface{})

	// Added Account ID
	accMap := map[string]interface{}{"nodeName": params["nodeName"]}
	condition["$and"] = append(condition["$and"], accMap)

	// // Added Key
	// keyMap := map[string]interface{}{params["key"]: params["value"]}
	// condition["$and"] = append(condition["$and"], keyMap)

	nvDao.log.Debugf("Read a notification channel, Query: %v and Param: %v", condition, params)
	d, e := db.Instance().ReadOne(nodevalidatorTable, condition)
	if e != nil {
		nvDao.log.Errorf("Failed on reading notification channel: '%s' error with '%s'", params["value"], e.Error())
		if strings.Contains(e.Error(), "not found") {
			return err.NewNotFound(directory.ErrorFmt("notification", "NFC_NOTFOUND", params["value"]))
		}
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	if tools.CopyStruct(d, nvDao); e != nil {
		nvDao.log.Errorf("Failed on converting notification channel dao: '%s' error with '%s'", params["value"], e.Error())
		return err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
	}
	return nil
}

// Query It does lists all recrods from db
func (nvDao *NodeValidatorDAO) Query(q interface{}, params Parameter) ([]interface{}, error) {
	if query, ok := q.(map[string][]map[string]interface{}); ok {
		// Added Account ID
		accMap := map[string]interface{}{"accountID": params["accountID"]}
		query["$and"] = append(query["$and"], accMap)
		p, _ := strconv.Atoi(params["page"])
		s, _ := strconv.Atoi(params["size"])
		field := "id"
		// This will help to order your results
		if params["field"] != "" {
			field = params["field"]
		}

		nvDao.log.Debugf("List notification channel, Query: %v and Param: %v", q, params)
		result, e := db.Instance().ReadPageBySort(nodevalidatorTable, query, field, p, s)
		if e != nil {
			nvDao.log.Errorf("Failed on listing notification channels: '%v' error with '%s'", q, e.Error())
			return result, err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
		}
		return result, nil
	}
	nvDao.log.Errorln("You gave invalid query parameter: ", q)
	return nil, err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
}

// GetTotal It does find out no of notification on given account
func (nvDao *NodeValidatorDAO) GetTotal(q interface{}, params Parameter) (int, error) {
	if query, ok := q.(map[string][]map[string]interface{}); ok {
		// Added Account ID
		accMap := map[string]interface{}{"accountID": params["accountID"]}
		query["$and"] = append(query["$and"], accMap)

		nvDao.log.Debugf("Notification channel total: %v and Param: %v", q, params)
		count, e := db.Instance().Count(nodevalidatorTable, query)
		if e != nil {
			nvDao.log.Errorf("Failed on getting notification channel total count: '%s' error with '%s'", nvDao.NodeName, e.Error())
			return 0, e
		}
		return count, nil
	}
	nvDao.log.Errorln("You gave invalid query parameter: ", q)
	return 0, err.NewInternalException(directory.ErrorFmt("all", "SOMETHING_WRONG"))
}

func (notification *NodeValidatorDAO) logger(log *logrus.Entry) {
	notification.log = log
}

// NewNotificationDAO It does creates a new notificaiton DAO with a id
// func NewNotificationDAO(log *logrus.Entry, accountID string) (*NodeValidatorDAO, error) {
// 	notificaitonID := ""
// 	for i := 0; i < 5; i++ {
// 		notificaitonID = uuid.New().String()
// 		notificaitonID = "nfc" + strings.Replace(notificaitonID, "-", "e", -1)
// 		aMap := map[string]interface{}{"id": notificaitonID}
// 		var condition = make(map[string][]map[string]interface{})
// 		condition["$and"] = append(condition["$and"], aMap)
// 		_, e := db.Instance().ReadOne(nodevalidatorTable, condition)
// 		if e != nil {
// 			// The id should be presented
// 			if strings.Contains(e.Error(), "not found") {
// 				break
// 			}
// 			log.Errorf("Unable to create a new id: %s", e.Error())
// 		}

// 		time.Sleep(10 * time.Second)
// 	}

// 	if notificaitonID == "" {
// 		return &NodeValidatorDAO{}, err.NewInternalException("Failed to create a new Notification Channel")
// 	}

// 	// TODO
// 	// To ensure 'conf' will not immediately followed by char 'f'
// 	result := strings.Split(notificaitonID, "")
// 	if result[4] != "e" {
// 		result[4] = "a"
// 	}

// 	notificaiton := &NodeValidatorDAO{}
// 	notificaiton.ID = strings.Join(result, "")
// 	notificaiton.AccountID = accountID
// 	notificaiton.CreatedTime = time.Now().UTC().String()
// 	return notificaiton, nil
// }
