package dao

import (
	"github.com/sirupsen/logrus"
)

// DataStore Database configuration
type DataStore struct {
	log *logrus.Entry `bson:"-"`
}

func NewDataStore(log *logrus.Entry) *DataStore {
	return &DataStore{log: log}
}

type Parameter map[string]string

// Reader handles all kinds of generic 'Read' operations
type Reader interface {
	// This method does read a particular record
	// The parameter tr is interface, which will be invoked based on given schema
	Read(tr TabReader, params Parameter) error

	// The Query does returns list of records who are all mets given conditions
	// The parameter tr is interface, which will be invoked based on given schema
	// The Parameter q will be a map of interface,
	// It returns list of matched results
	Query(tr TabReader, q interface{}, params Parameter) ([]interface{}, error)

	// The GetTotal does returns list of collections on given schema
	// The parameter tr is interface, which will be invoked based on given schema
	GetTotal(tr TabReader, q interface{}, params Parameter) (int, error)
}

// Writter handles all kinds of generic 'Write' operations
type Writter interface {

	// This method writes given collection into a particular table
	// The parameter tw is interface, which will be invoked based on given schema
	// Returns nil if no error otherwise returns errors
	Write(tw TabWritter) error

	// This method does delete the specified collection in table
	// The parameter tw is interface, which will be invoked based on given schema
	// Returns nil if no error otherwise returns errors
	Delete(tw TabWritter, params Parameter) error

	// This method updates the specified collection in the table
	// The parameter tw is interface, which will be invoked based on given schema
	// Returns nil if no error otherwise returns errors
	Update(tw TabWritter, params Parameter) error
}

// ReadWritter is a Combination read and write operations
type ReadWritter interface {
	Reader
	Writter
}

// TabReader does basic Database read operations
type TabReader interface {
	// This method is derived from Reader
	Read(params Parameter) error

	// This method is derived from Reader
	Query(q interface{}, params Parameter) ([]interface{}, error)

	// This method is derived from Reader
	GetTotal(q interface{}, params Parameter) (int, error)

	logger(log *logrus.Entry)
}

// TabWritter does basic Database write operations
type TabWritter interface {

	// This method is derived from Writter
	Write() error

	// This method is derived from Writter
	Update(params Parameter) error

	// This method is derived from Writter
	Delete(params Parameter) error

	// All read operations
	TabReader
}

// Common read operations

// Read does generic read operations
func (ds *DataStore) Read(tr TabReader, params Parameter) error {
	tr.logger(ds.log)
	// params["accountID"] = ds.AccountID
	// params["organizationID"] = ds.OrganizationID
	return tr.Read(params)
}

// Query does generic query operations
func (ds *DataStore) Query(tr TabReader, q interface{}, params Parameter) ([]interface{}, error) {
	tr.logger(ds.log)
	// params["accountID"] = ds.AccountID
	// params["organizationID"] = ds.OrganizationID
	return tr.Query(q, params)
}

// GetTotal returns total no of records found in specified schema
func (ds *DataStore) GetTotal(tr TabReader, q interface{}, params Parameter) (int, error) {
	tr.logger(ds.log)
	// params["accountID"] = ds.AccountID
	// params["organizationID"] = ds.OrganizationID
	return tr.GetTotal(q, params)
}

// Common write operations

// Write does generic write operation
func (ds *DataStore) Write(tw TabWritter) error {
	tw.logger(ds.log)
	return tw.Write()
}

// Delete receives generic delete operations
func (ds *DataStore) Delete(tw TabWritter, params Parameter) error {
	tw.logger(ds.log)
	// params["accountID"] = ds.AccountID
	// params["organizationID"] = ds.OrganizationID
	return tw.Delete(params)
}

// Update does generic update operation
func (ds *DataStore) Update(tw TabWritter, params Parameter) error {
	tw.logger(ds.log)
	return tw.Update(params)
}
